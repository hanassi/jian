package com.example.jian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JianApplicationTests {

	@Test
	void contextLoads() {
	}

}
