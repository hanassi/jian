package com.jian.vendys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendysApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendysApplication.class, args);
	}

}
